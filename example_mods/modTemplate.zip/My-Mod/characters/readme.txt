Put your custom character .json files here!

You can create a custom character using the Character Editor by pressing 7 in the main menu.

For more info, go here:
https://github.com/ShadowMario/FNF-PsychEngine/wiki/Creating-a-Character