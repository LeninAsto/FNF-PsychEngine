Add your custom event's .txt file and .lua file here

The .txt file is the event's description in the Chart Editor

For more info, go here:
https://github.com/ShadowMario/FNF-PsychEngine/wiki/Creating-an-Event