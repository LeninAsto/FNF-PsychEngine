Put your translated assets here! (optional)

For assets that are found within images/ subdirectories:
<lang>/<subdir>/image.png

For assets that are found within the root of images/:
<lang>/image.png

!!FOLDER NAME MUST MATCH .LANG FILE WITHIN DATA!!